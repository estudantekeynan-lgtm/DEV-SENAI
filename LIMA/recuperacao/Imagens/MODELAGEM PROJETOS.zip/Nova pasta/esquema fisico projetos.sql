-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE OPERADORES (
id_operador INT AUTO PRIMARY KEY PRIMARY KEY,
nome VARCHAR(60),
telefone VARHAR(20),
noturno Texto(1),
diurno Texto(1)
)

CREATE TABLE ITEM_PRODUCAO (
id_producao INT AUTO INCREMENT PRIMARY KEY PRIMARY KEY,
quantidade INT,
inativo Texto(1),
ativo Texto(1),
turno_producao ENUM(' NOTURNO','DIURNO')
)

CREATE TABLE PRODUTO (
id_produto INT AUTO INCREMENT PRIMARY KEY PRIMARY KEY,
quantidade INT,
descricao varchar(60),
preco DECIMAL (10,2)
)

CREATE TABLE MAQUINAS (
id_maquina INT AUTO INCREMENT PRIMARY KEY PRIMARY KEY,
modelo VARCHAR(60),
operador VARCHAR(60),
ligado ENUM,
desligado ENUM
)

CREATE TABLE ORDEM_PRODUCAO (
id_ordem INT AUTO INCREMENT PRIMARY KEY PRIMARY KEY,
data_inicio date,
prioridade ENUM (' BAIXA','ALTA'),
prazo DATE NOT NULL
)

CREATE TABLE CONT�M (
id_producao INT AUTO INCREMENT PRIMARY KEY,
id_ordem INT AUTO INCREMENT PRIMARY KEY,
FOREIGN KEY(id_producao) REFERENCES ITEM_PRODUCAO (id_producao),
FOREIGN KEY(id_ordem) REFERENCES ORDEM_PRODUCAO (id_ordem)
)

CREATE TABLE REALIZA (
id_ordem INT AUTO INCREMENT PRIMARY KEY,
id_maquina INT AUTO INCREMENT PRIMARY KEY,
FOREIGN KEY(id_ordem) REFERENCES ORDEM_PRODUCAO (id_ordem),
FOREIGN KEY(id_maquina) REFERENCES MAQUINAS (id_maquina)
)

CREATE TABLE IDENTIFICA (
id_producao INT AUTO INCREMENT PRIMARY KEY,
id_produto INT AUTO INCREMENT PRIMARY KEY,
FOREIGN KEY(id_producao) REFERENCES ITEM_PRODUCAO (id_producao),
FOREIGN KEY(id_produto) REFERENCES PRODUTO (id_produto)
)

CREATE TABLE ADMINISTRAM (
id_ordem INT AUTO INCREMENT PRIMARY KEY,
id_operador INT AUTO PRIMARY KEY,
FOREIGN KEY(id_ordem) REFERENCES ORDEM_PRODUCAO (id_ordem)/*falha: chave estrangeira*/
)

